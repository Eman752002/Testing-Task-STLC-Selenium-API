package Models.CurrentWaether;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class Weather {

    @JsonIgnoreProperties(ignoreUnknown = true)
        private String icon;
        private int code;
        private String description;

        // Getters and setters
        public String getIcon() { return icon; }
        public void setIcon(String icon) { this.icon = icon; }

        public int getCode() { return code; }
        public void setCode(int code) { this.code = code; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
    }



package Models.CurrentWaether;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.xml.crypto.Data;
import java.util.List;

public class CurrentWeatherResponse {



    @JsonIgnoreProperties(ignoreUnknown = true)
    public class WeatherResponse {
        private List<Data> data;
        private int count;

        // Getters and setters
        public List<Data> getData() { return data; }
        public void setData(List<Data> data) { this.data = data; }

        public int getCount() { return count; }
        public void setCount(int count) { this.count = count; }
    }

}

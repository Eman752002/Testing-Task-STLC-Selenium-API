package Models.AirQuality;

import DataSteps.AirQualityData;

import java.util.List;

public class AirQualityResponse {

    public double lat;
    public double lon;
    public String timezone;
    public String city_name;
    public String country_code;
    public String state_code;

    public List<AirQualityData> data;
}
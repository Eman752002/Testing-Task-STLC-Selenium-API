package Models.NormalClimate;

import java.util.List;

public class NormalClimateResponse {
    public double lat;
    public double lon;
    public String timezone;
    public List<String> sources;
    public List<DailyData> data;

    public static class DailyData {
        public double temp;
        public int day;
        public int month;
    }
}

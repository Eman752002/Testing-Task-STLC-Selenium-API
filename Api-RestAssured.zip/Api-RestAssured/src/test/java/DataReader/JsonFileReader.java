package DataReader;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;


public class JsonFileReader {
    static File userDataFile;
    static File dataBaseFile;

    public static UserData readUserDataFile() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper(); // create Object from Object Mapper
        //------------------------------------Staging User Data ------------------------------
//        userDataFile = new File("src/test/resources/UsersData_Staging.json");
        //------------------------------------Testing User Data ------------------------------
        userDataFile = new File("src/test/resources/UsersData_Testing.json");
        // Convert json file into User Data object and Return it
        return objectMapper.readValue(userDataFile, UserData.class);
    }

    public static DataBaseData readDataBaseFile() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper(); // create Object from Object Mapper
        //------------------------------------Staging DataBase Data ------------------------------
//        dataBaseFile = new File("src/test/resources/DataBaseData_Staging.json");
        //------------------------------------Testing DataBase Data ------------------------------
        dataBaseFile = new File("src/test/resources/DataBaseData_Testing.json");
        // Convert json file into DataBaseData object and Return it
        return objectMapper.readValue(dataBaseFile, DataBaseData.class);

    }
}
package DataReader;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataBaseData {
    public JsonNode JsonNode;
    public String DataBaseURL;
    public String TrackID;
    public String OrganizationID;

    public String getOrganizationID() {
        return OrganizationID;
    }

    public com.fasterxml.jackson.databind.JsonNode getJsonNode() {
        return JsonNode;
    }

    public void setJsonNode(com.fasterxml.jackson.databind.JsonNode jsonNode) {
        JsonNode = jsonNode;
    }

    public String getDataBaseURL() {
        return DataBaseURL;
    }

    public void setDataBaseURL(String dataBaseURL) {
        DataBaseURL = dataBaseURL;
    }

    public String getTrackID() {
        return TrackID;
    }

    public void setTrackID(String trackID) {
        TrackID = trackID;
    }
}

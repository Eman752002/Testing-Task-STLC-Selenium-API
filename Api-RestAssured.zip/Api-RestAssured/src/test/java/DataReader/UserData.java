package DataReader;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserData {
    public String LCAdmin;
    public String LCTrainingCoordinator;
    public String LCInstructor;
    public String LCTrainee;
    public String LCCustomTrainee;
    public String Password;


    public String getLCAdmin() {
        return LCAdmin;
    }

    public void setLCAdmin(String LCAdmin) {
        this.LCAdmin = LCAdmin;
    }

    public String getLCTrainingCoordinator() {
        return LCTrainingCoordinator;
    }

    public void setLCTrainingCoordinator(String LCTrainingCoordinator) {
        this.LCTrainingCoordinator = LCTrainingCoordinator;
    }

    public String getLCInstructor() {
        return LCInstructor;
    }

    public void setLCInstructor(String LCInstructor) {
        this.LCInstructor = LCInstructor;
    }

    public String getLCTrainee() {
        return LCTrainee;
    }

    public void setLCTrainee(String LCTrainee) {
        this.LCTrainee = LCTrainee;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }
}

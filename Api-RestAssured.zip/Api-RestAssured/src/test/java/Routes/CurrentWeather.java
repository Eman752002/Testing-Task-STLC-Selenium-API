package Routes;

public class CurrentWeather {
    public static final String CURRENT_WEATHER_EndPoint = "/current";

}

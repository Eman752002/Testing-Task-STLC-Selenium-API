package Routes;

public class BaseRoutes {
    //------------------------------------Staging Base URL------------------------------
//    public static final String BASEURL = "";
    //------------------------------------Testing Base URL------------------------------
    public static final String BASEURL = "https://api.weatherbit.io/v2.0";

    //------------------------------------ Auth API ------------------------------
    public static String apikey = "12cec1d2dd1043a2ac23d11d6328fd3d";
}

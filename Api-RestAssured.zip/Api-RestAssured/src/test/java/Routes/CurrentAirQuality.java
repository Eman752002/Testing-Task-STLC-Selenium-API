package Routes;

public class CurrentAirQuality {
    //--------------------------------------------  ---------------------------------
    public static final String GET_AIRQUALITY = "/current/airquality";

}
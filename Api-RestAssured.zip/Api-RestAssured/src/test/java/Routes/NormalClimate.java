package Routes;

public class NormalClimate {
    public static final String NORMALS_ENDPOINT = "/normals";

}

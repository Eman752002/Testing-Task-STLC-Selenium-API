package Clients.AirQuality;

import Routes.BaseRoutes;
import Routes.CurrentAirQuality;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class AirQualityClient {

    public Response getAirQualityByLatLon(double lat, double lon) {

        return RestAssured.given()
                .baseUri(BaseRoutes.BASEURL)
                .queryParam("lat", lat)
                .queryParam("lon", lon)
                .queryParam("key", BaseRoutes.apikey)
                .when()
                .get(CurrentAirQuality.GET_AIRQUALITY);
    }
    public Response getAirQualityWithoutLocation() {

        return RestAssured.given()
                .baseUri(BaseRoutes.BASEURL)
                .queryParam("key", BaseRoutes.apikey)
                .when()
                .get(CurrentAirQuality.GET_AIRQUALITY);

    }
}

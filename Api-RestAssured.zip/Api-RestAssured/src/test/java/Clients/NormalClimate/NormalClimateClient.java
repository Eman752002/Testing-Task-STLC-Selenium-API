
package Clients.NormalClimate;

import Routes.BaseRoutes;
import Routes.NormalClimate;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class NormalClimateClient {

    private String apiKey;

    public NormalClimateClient(String apiKey) {
        this.apiKey = apiKey;
    }

    public Response getNormals(String startDay, String endDay,
                               String units, String tp, String seriesYear) {

        return RestAssured.given()
                .baseUri(BaseRoutes.BASEURL)
                .queryParam("start_day", startDay)
                .queryParam("end_day", endDay)
                .queryParam("units", units)
                .queryParam("tp", tp)
                .queryParam("series_year", seriesYear)
                .queryParam("key", apiKey)
                .when()
                .get(NormalClimate.NORMALS_ENDPOINT);
    }

    // Invalid test: start date > end date
    public Response getNormalsInvalidRange(String startDay, String endDay) {
        return RestAssured.given()
                .baseUri(BaseRoutes.BASEURL)
                .queryParam("start_day", startDay)
                .queryParam("end_day", endDay)
                .queryParam("key", apiKey)
                .when()
                .get(NormalClimate.NORMALS_ENDPOINT);
    }
}

package Clients.CurrentWeather;

import Models.CurrentWaether.CurrentWeatherResponse;
import Models.NormalClimate.NormalClimateResponse;
import Routes.BaseRoutes;
import Routes.CurrentWeather;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import static Routes.BaseRoutes.apikey;
import static Routes.CurrentWeather.CURRENT_WEATHER_EndPoint;
import static io.restassured.RestAssured.given;

public class CurrentWeatherClient {




        // GET current weather by city
        public CurrentWeatherResponse.WeatherResponse getCurrentWeatherByCity(String city) {
            Response response = given()
                    .baseUri(BaseRoutes.BASEURL)
                    .queryParam("city", city)
                    .queryParam("key", apikey)
                    .get(CurrentWeather.CURRENT_WEATHER_EndPoint)
                    .then()
                    .statusCode(200)
                    .extract()
                    .response();

            return response.as(CurrentWeatherResponse.WeatherResponse.class);
        }

        // GET current weather with invalid parameters
        public Response getCurrentWeatherInvalid(String invalidParam) {
            return given()
                    .baseUri(BaseRoutes.BASEURL)
                    .queryParam("invalid", invalidParam)
                    .queryParam("key", apikey)
                    .get(CurrentWeather.CURRENT_WEATHER_EndPoint)
                    .then()
                    .extract()
                    .response();
        }
    }



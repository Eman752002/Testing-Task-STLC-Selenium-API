package DataSteps;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AirQualityData {

    public int aqi;
    public double o3;
    public double so2;
    public double no2;
    public double co;
    public int pm10;
    public int pm25;

    public int pollen_level_tree;
    public int pollen_level_grass;
    public int pollen_level_weed;
    public int mold_level;

    public String predominant_pollen_type;
}

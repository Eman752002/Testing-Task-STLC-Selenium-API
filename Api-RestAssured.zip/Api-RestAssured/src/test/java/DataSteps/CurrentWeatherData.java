package DataSteps;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.github.javafaker.Weather;

public class CurrentWeatherData {


    @JsonIgnoreProperties(ignoreUnknown = true)
    public class Data {
        private String city_name;
        private double temp;
        private Weather weather;

        // Getters and setters
        public String getCity_name() { return city_name; }
        public void setCity_name(String city_name) { this.city_name = city_name; }

        public double getTemp() { return temp; }
        public void setTemp(double temp) { this.temp = temp; }

        public Weather getWeather() { return weather; }
        public void setWeather(Weather weather) { this.weather = weather; }
    }


}

package DataSteps;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class NormalClimateData {

@JsonIgnoreProperties(ignoreUnknown = true)
    public Double dewpt;
    public Double snow;
    public Double min_wind_spd;
    public Integer wind_dir;
    public Integer hour;
    public Integer month;
    public Double max_temp;
    public Integer day;
    public Double wind_spd;
    public Double temp;
    public Double min_temp;
    public Double max_wind_spd;
    public Double precip;
}

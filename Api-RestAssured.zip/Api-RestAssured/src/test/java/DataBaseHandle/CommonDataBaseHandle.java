package DataBaseHandle;

import DataReader.DataBaseData;

import java.sql.*;
import java.util.Map;

public class CommonDataBaseHandle {

    public static Map<String, Object> getCustomField(DataBaseData dataBaseData) throws SQLException {
        Connection connection = DriverManager.getConnection(dataBaseData.getDataBaseURL());
        String query = " select * from CustomFields " +
                "  Where OrganizationId='" + dataBaseData.getOrganizationID() + "' ";

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        Map<String, Object> customField = Map.of();

        while (resultSet.next()) {
            customField = Map.of("Id", resultSet.getInt("Id")
                    , "Value", resultSet.getString("Name"));
        }
        return customField;
    }
}

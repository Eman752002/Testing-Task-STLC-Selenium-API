package DataBaseHandle;

import DataReader.DataBaseData;

import java.sql.*;


public class RoomDataBaseHandle {
    static Connection connection;

    public static void connectWithDataBase(String DataBaseUrl) throws SQLException {
        connection = DriverManager.getConnection(DataBaseUrl); // Get Connection from Data Base
    }

    public static int getRoomsInOrganization(DataBaseData dataBaseData) throws SQLException {
        connectWithDataBase(dataBaseData.getDataBaseURL());
        String query = "Select Count(*) As Total from Rooms " +
                "Where OrganizationID = '" + dataBaseData.OrganizationID + "'";
        Statement statement = connection.createStatement(); // Create Statement
        ResultSet resultSet = statement.executeQuery(query); /// Execute Query
        int rowCount = 0;
        while (resultSet.next()) {
            rowCount = resultSet.getInt("Total"); // Get Count Value of the Column Total
        }
        return rowCount;
    }

    public static void deleteRoom(DataBaseData dataBaseData, int roomID) throws SQLException {
        connectWithDataBase(dataBaseData.getDataBaseURL());
        String query = "Delete from Rooms " +
                "Where OrganizationID = '" + dataBaseData.OrganizationID +
                "' And Id = " + roomID;
        Statement statement = connection.createStatement(); // Create Statement
        statement.executeUpdate(query);
    }

}

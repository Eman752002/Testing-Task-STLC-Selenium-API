package DataBaseHandle;

import DataReader.DataBaseData;

import java.sql.*;

public class TrackDataBaseHandle {

    public static void createTrack(DataBaseData dataBaseData) throws SQLException {
        Connection connection = DriverManager.getConnection(dataBaseData.getDataBaseURL());
        String query = "INSERT INTO Track " +
                "(Id, Title, Description)" +
                "VALUES ('" + dataBaseData.getTrackID() + "', 'API Automation Track Certificate', '')";
        Statement statement = connection.createStatement(); // Create Statement
        statement.executeUpdate(query); // Execute Query
    }
}

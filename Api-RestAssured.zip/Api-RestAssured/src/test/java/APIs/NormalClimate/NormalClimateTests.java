package APIs.NormalClimate;


import Clients.NormalClimate.NormalClimateClient;
import Models.NormalClimate.NormalClimateResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class NormalClimateTests {

    NormalClimateClient client;
    ObjectMapper mapper;

    @BeforeClass
    public void setup() {
        client = new NormalClimateClient("12cec1d2dd1043a2ac23d11d6328fd3d");
        mapper = new ObjectMapper();
    }

    @Test
    public void validNormalsTest() throws Exception {


        Response response = client.getNormals("02-01", "02-05", "m", "daily", "2020");
        response.then().log().all();
        System.out.println(response.asString());
        assertThat(response.getStatusCode(), is(200));

        // Convert response to POJO
        NormalClimateResponse body =
                mapper.readValue(response.getBody().asString(), NormalClimateResponse.class);

        // Expect exactly 5 records
        assertThat(body.data.size(), is(5));

        // Validate day/month/temp
        body.data.forEach(item -> {
            assertThat(item.day, greaterThan(0));
            assertThat(item.month, greaterThan(0));
            assertThat(item.temp, notNullValue());
        });
    }

    @Test
    public void invalidDateRangeTest() {

        Response response = client.getNormalsInvalidRange("02-10", "02-05");

        // Expect 400 Bad Request
        assertThat(response.getStatusCode(), is(400));

        // Body contains "invalid"
        assertThat(response.getBody().asString().toLowerCase(),
                containsString("invalid"));
    }
}

package APIs.CurrentWeather;

import Clients.CurrentWeather.CurrentWeatherClient;
import Models.CurrentWaether.CurrentWeatherResponse;
import io.restassured.response.Response;
import org.junit.Test;
import org.testng.Assert;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class CurrentWeatherTests {


    CurrentWeatherClient client = new CurrentWeatherClient();

        @Test
        public void testValidWeatherByCity() {
            CurrentWeatherResponse.WeatherResponse response = client.getCurrentWeatherByCity("Raleigh");
            assertThat(response.getCount(), greaterThan(0));
        }

    @Test
    public void testInvalidParameter() {
        Response response = client.getCurrentWeatherInvalid("invalidValue");

        // Assert status code
        Assert.assertEquals(response.getStatusCode(), 400);

        // Assert error message (adjust the JSON path based on actual response)
        String errorMessage = response.jsonPath().getString("error");
        org.testng.Assert.assertTrue(errorMessage != null && errorMessage.toLowerCase().contains("invalid parameters"),
                "Expected error message to contain 'Invalid Parameters'");
    }

}



package APIs.AirQuality;

import Clients.AirQuality.AirQualityClient;
import io.restassured.http.ContentType;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.containsStringIgnoringCase;


public class AirQualityTests {
    AirQualityClient client = new AirQualityClient();

    @Test
    public void verifyAirQualityResponse() {


        client.getAirQualityByLatLon(35.7721, -78.63861)
                .then()
                .statusCode(200)
                .body("data[0].aqi", notNullValue());
    }

    @Test
    public void verifyMissingLocationParameters() {

        client.getAirQualityWithoutLocation()
                .then()
                .statusCode(400)
                .contentType(ContentType.JSON)
                .body("error", containsStringIgnoringCase("Invalid Parameters supplied"));
    }
}

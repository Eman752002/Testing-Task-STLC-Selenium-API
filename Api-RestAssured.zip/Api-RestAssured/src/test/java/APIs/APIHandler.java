package APIs;

import Routes.BaseRoutes;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.util.Map;

import static io.restassured.RestAssured.given;


public class APIHandler {

    public enum Method_Type {
        Get,
        Post,
        Put,
        Patch,
        Delete
    }

    // BasicAPI
    public static Response BasicAPI(Method_Type methodType, final String APIEndPoint, String token) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .auth().oauth2(token)
                .contentType("application/json")
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    public static Response BasicAPIWithoutToken(Method_Type methodType, final String APIEndPoint) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .contentType("application/json")
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    // APIs Cases with Body
    public static Response APIBody(Method_Type methodType, final String APIEndPoint, String token, Object body) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .auth().oauth2(token)
                .contentType("application/json")
                .body(body)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    public static Response APIBodyWithoutToken(Method_Type methodType, final String APIEndPoint, Object body) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .contentType("application/json")
                .body(body)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    public static Response APIBodyWithoutContentType(Method_Type methodType, final String APIEndPoint, String token, Object body) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .auth().oauth2(token)
                .body(body)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    // APIs Cases with Query Parameter
    public static Response APIQueryParameter(Method_Type methodType, final String APIEndPoint, String token, Map<String, Object> queryParams) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .contentType("application/json")
                .auth().oauth2(token)
                .queryParams(queryParams)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    public static Response APIQueryParameterWithoutToken(Method_Type methodType, final String APIEndPoint, Map<String, Object> queryParams) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .queryParams(queryParams)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    // APIs Cases With Path Parameter
    public static Response APIPathParameter(Method_Type methodType, final String APIEndPoint, String token, Map<String, Object> pathParams) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .auth().oauth2(token)
                .pathParams(pathParams)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    public static Response APIPathParameterWithoutToken(Method_Type methodType, final String APIEndPoint, Map<String, Object> pathParams) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .pathParams(pathParams)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    // APIs Cases With Query Parameter and Body Parameter
    public static Response APIQueryParamAndBody(Method_Type methodType, final String APIEndPoint, String token, Map<String, Object> queryParams, Object body) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .contentType("application/json")
                .auth().oauth2(token)
                .queryParams(queryParams)
                .body(body)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    public static Response APIQueryParamAndBodyWithoutToken(Method_Type methodType, final String APIEndPoint, Map<String, Object> queryParams, Object body) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .queryParams(queryParams)
                .body(body)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    public static Response APIQueryParamAndBodyWithoutContentType(Method_Type methodType, final String APIEndPoint, String token, Map<String, Object> queryParams, Object body) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .auth().oauth2(token)
                .queryParams(queryParams)
                .body(body)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    // APIs Cases With File
    public static Response APIFile(Method_Type methodType, final String APIEndPoint, String token, File file) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .auth().oauth2(token)
                .multiPart("uploadFile", file)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }

    public static Response APIFileWithoutToken(Method_Type methodType, final String APIEndPoint, File file) {
        RequestSpecification requestSpecification = given()
                .baseUri(BaseRoutes.BASEURL)
                .multiPart("uploadFile", file)
                .when();

        return methodType == Method_Type.Get ? requestSpecification.get(APIEndPoint)
                : methodType == Method_Type.Post ? requestSpecification.post(APIEndPoint)
                : methodType == Method_Type.Delete ? requestSpecification.delete(APIEndPoint)
                : methodType == Method_Type.Put ? requestSpecification.put(APIEndPoint)
                : requestSpecification.patch(APIEndPoint);
    }
}
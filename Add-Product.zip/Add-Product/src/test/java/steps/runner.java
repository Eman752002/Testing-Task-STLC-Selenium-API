package steps;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
//Add_ItemsToCard.feature
@CucumberOptions(
        features = {"src/test/resources/Features/Add_ItemsToCard.feature"},
        glue = {"steps"},tags="@testcase1",
        plugin = {"pretty", "html:target/reports/report.html"}
)
public class runner extends AbstractTestNGCucumberTests {

}



package steps.ProductsSteps;
import Vodafone.pages.AddProductsPages.BuyProductPopUpPage;
import Vodafone.pages.AddProductsPages.CardDetailsPage;
import Vodafone.pages.CommomPages.Homepage;
import Vodafone.pages.CommomPages.loginpage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import Vodafone.pages.CommomPages.base;
import org.testng.Assert;

public class AddProductSteps extends base {
    loginpage loginpageobj=new loginpage();
    Homepage homepage=new Homepage();
    BuyProductPopUpPage buyProductPopUpPage=new BuyProductPopUpPage();
    Vodafone.pages.AddProductsPages.CardDetailsPage CardDetailsPage=new CardDetailsPage();

    @Given("User Fill {string} And {string}")
    public void UserFillEmailAndPasswordasAdmin(String PhoneNumber,String password) throws InterruptedException {
        String Email=properties.getProperty(PhoneNumber);
        String Password=properties.getProperty(password);
        loginpageobj.login(Email,Password);
    }


    @And("Click on the card icon for the first item")
    public void clickOnTheCardIconForTheFirstItem() {
        homepage.ClickOnTheFirstItem();
    }

    @And("Click on the Add to card button")
    public void clickOnTheAddToCardButton() {

        buyProductPopUpPage.clickOnTheAddToCardButton();
    }

    @And("Click on the card icon for the Second item")
    public void clickOnTheCardIconForTheSecondItem()  {

        homepage.clickOnTheSecondItem();
    }


    @And("Search for the third item")
    public void searchForTheThirdItem() {

        homepage.searchForTheThirdItem();
    }

    @And("Click on the card icon for the third item")
    public void clickOnTheCardIconForTheThirdItem() {

        homepage.ClickOnTheThirdItem();
    }

    @And("Click on the Add to card button After Search")
    public void clickOnTheAddToCardButtonAfterSearch() {
        buyProductPopUpPage.clickOnTheAddToCardButtonAfterSearch();
    }

    @And("Click on the card page")
    public void clickOnTheCardPage() {
        homepage.clickOnTheCardButton();

    }

    @Then("Check that the three items are in the card")
    public void checkThatTheThreeItemsAreInTheCard() {
        Assert.assertEquals(CardDetailsPage.CheckNumberOfSelectedItems(),"( 3 Items )");

    }

    @And("Delete All selected items")
    public void deleteAllSelectedItems() throws InterruptedException {
        CardDetailsPage.deleteAllItems();


    }
}








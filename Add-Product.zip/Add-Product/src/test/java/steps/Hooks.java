package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import Vodafone.pages.CommomPages.base;
import steps.ProductsSteps.AddProductSteps;

public class Hooks extends base {
    AddProductSteps addProductSteps =new AddProductSteps();
    @Before
   public void start()
    {
       launchbrowser();
    }

    @After
    public void quit()
    {
        driver.quit();
    }
}


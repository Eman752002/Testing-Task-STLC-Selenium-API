package Vodafone.pages.CommomPages;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class loginpage extends base {
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    By loginBtn=By.xpath("//p[normalize-space()='Login']");
    By userName =By.id("username");
    By Password = By.id("password");
    By goToMyAccount= By.id("submitBtn");

    public void login(String PhoneNumber, String password) throws InterruptedException {
        driver.findElement(loginBtn).click();
        driver.findElement(userName).sendKeys(PhoneNumber);
        driver.findElement(Password).sendKeys(password);
        driver.findElement(goToMyAccount).click();
    }
}
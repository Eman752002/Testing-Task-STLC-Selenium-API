package Vodafone.pages.CommomPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Homepage extends base {
    WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(10));

    By SelectFirstItem=By.xpath("(//img[@alt='cart'])[2]");
    By SelectSecondItem=By.xpath("(//img[@alt='cart'])[3]");
    By SelectThirdItem=By.xpath("(//a[@role='link'])[1]");

    By searchField=By.id("searchInput");
    By cardButton=By.xpath("(//img[@id='sl-nav-bar-img=6'])[1]");
    public void ClickOnTheFirstItem()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 800);");
        wait.until(ExpectedConditions.presenceOfElementLocated(SelectFirstItem)).click();
    }
    public void clickOnTheSecondItem()
    {

        wait.until(ExpectedConditions.presenceOfElementLocated(SelectSecondItem)).click();
    }
    public void ClickOnTheThirdItem()
    {
        wait.until(ExpectedConditions.elementToBeClickable(SelectThirdItem)).click();
    }

    public void searchForTheThirdItem()  {

        wait.until(ExpectedConditions.presenceOfElementLocated(searchField)).sendKeys("labtop");
        driver.findElement(searchField).sendKeys(Keys.ENTER);

    }
    public void clickOnTheCardButton()
    {

        wait.until(ExpectedConditions.presenceOfElementLocated(cardButton)).click();

    }

}
package Vodafone.pages.AddProductsPages;

import Vodafone.pages.CommomPages.base;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class CardDetailsPage extends base {
    By numberOfSelectedItems=By.xpath("//span[normalize-space()='( 3 Items )']");
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    By deleteIcon=By.xpath("(//p[contains(text(),'Remove')])");

    public String CheckNumberOfSelectedItems() {

        return driver.findElement(numberOfSelectedItems).getText();}

    public void deleteAllItems() throws InterruptedException {


        for (int i = 0; i < 3; i++) {
            List<WebElement> deletes = driver.findElements(deleteIcon);
            wait.until(ExpectedConditions.elementToBeClickable(deletes.get(0))).click();
            Thread.sleep(2000);
            // I used for loop with list because I call one element three times
            // I used all dynamics waits ,but it doesn't work soo immediately I used Thread.sleep
        }



    }
}


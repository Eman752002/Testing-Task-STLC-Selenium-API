package Vodafone.pages.AddProductsPages;

import Vodafone.pages.CommomPages.base;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BuyProductPopUpPage extends base {
    WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(10));
    By addToCardButton= By.xpath("//button[normalize-space()='Add To Cart']");
    By AddToCardButtonAfterSearch=By.xpath("//div[@class='actions-container']//button[@class='add-to-cart ng-star-inserted'][normalize-space()='Add To Cart']");
    public void clickOnTheAddToCardButton(){

        wait.until(ExpectedConditions.elementToBeClickable(addToCardButton)).click();

    }
    public void clickOnTheAddToCardButtonAfterSearch(){
        wait.until(ExpectedConditions.elementToBeClickable(AddToCardButtonAfterSearch)).click();

    }


}